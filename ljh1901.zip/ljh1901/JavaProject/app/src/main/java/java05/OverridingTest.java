package java05;

class Parents {
    // Parent Class의 method
    public void info() {
        System.out.println("부모 클래스입니다...");
    }
}

class Child extends Parents {
    // Parent Class의 method를 inheritance한 child Class
    @Override
    public void info() {
        super.info(); // Parent Class의 method 호출
        System.out.println("자식 클래스입니다..");
    }
}

public class OverridingTest {
    public static void main(String[] args) {
        // Child Class의 Obejct 생성
        Child son = new Child();
        
        // Child Class의 method 호출
        son.info();
    }
}

