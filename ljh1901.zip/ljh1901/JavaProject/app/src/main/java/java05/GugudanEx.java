package java05;

public class GugudanEx {
    public static void main(String[] args) {
        // 2차원 배열 gugudan 정의
        int[][] gugudan = new int[10][10];

        // 각 단을 출력하는 for문
        for (int i = 1; i < gugudan.length; i++) {
            System.out.println("-----------------------------");
            System.out.println(i + "단");
            System.out.println("-----------------------------");

            // 각 단의 구구단을 계산하고 출력하는 반복문
            for (int j = 1; j < gugudan[i].length; j++) {
                gugudan[i][j] = i * j;

                // 각 구구단의 결과 출력
                System.out.println(i + "x" + j + "=" + gugudan[i][j]);

                // 한 줄 출력 후 줄바꿈
                if (j == 9) {
                    System.out.println("\n");
                }
            }
        }
    }

}
