package java05;

class Test {
    // method overloading
    public void smart(int num) {
        System.out.println(num + "은 정수입니다..");
    }
    public void smart(double num) {
        System.out.println(num + "은 실수입니다..");
    }
    public void smart(String num) {
        System.out.println(num + "은 문자열입니다..");
    }
}

public class PolymorphismTest {
    public static void main(String[] args) {
        // Object 생성
        Test smu = new Test();

        smu.smart(33);
        smu.smart(33.33);
        smu.smart("SmartIT");
    }
}
