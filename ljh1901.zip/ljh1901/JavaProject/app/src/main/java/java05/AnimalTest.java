package java05;

class Animal {
    // Animal Class의 Constructor
    public Animal(String s) {
        System.out.println("동물 : " + s);
    }
}

class Mammal extends Animal {
    // Mammal Class의 default constructor
    public Mammal() {
        // super(); // 부모 클래스에 default constructor가 없음.
        // 부모 클래스인 Animal 클래스의 Constructor 호출
        super("원숭이");
        System.out.println("포유류 : 원숭이");
    }

    // Mammal Class의 parameter가 있는 Constructor
    public Mammal(String s) {
        // [6] Super Class인 Animal Class()의 Constructor 호출
        super(s); // [Animal Class의 Constructor 호출
        System.out.println("포유류 : " + s);
    }
}

public class AnimalTest {
    public static void main(String[] args) {
        // Mammal Class의 default constructor를 이용한 Object 생성
        Mammal ape = new Mammal();
        
        // [9] Mammal Class의 parameter가 있는 Constructor를 이용한 Object 생성
        Mammal lion = new Mammal("사자");
    }
}

