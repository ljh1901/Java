package java05;

import java.util.Scanner;

public class DayTestEx {
    public static void main(String[] args) {
        // 문자열 입력 받기
        Scanner in = new Scanner(System.in);
        String s = in.next();

        // 입력받은 문자열을 대문자로 받고, Day 상수로 Convert
        Day day = Day.valueOf(s.toUpperCase());

        // 변환된 Day 열거형 상수에 따라 Method 호출
        dayIsLike(day);
    }
    
    // [4] Day 열거형 상수를 사용하여 출력하는 Method
    public static void dayIsLike(Day day) {
        switch (day) {
            case MONDAY:
                System.out.println("월요일은 싫다..");
                break;
            case FRIDAY:
                System.out.println("금요일은 좋다..");
                break;
            case SATURDAY:
            case SUNDAY:
                System.out.println("주말은 최고..");
                break;
            default:
                System.out.println("그저 그렇다..");
        }
    }
}

// Day 열거형 정의
enum Day {
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
}
