package java05;

public class StringForEx {
    public static void main(String[] args) {
        int i = 33;

        System.out.println("i = " + i);

        //뒤의 333은 문자열 결합
        System.out.println(3 + 33 + "SmartIT " + 3 + 33); //36SmartIT 333

    }
    
}
