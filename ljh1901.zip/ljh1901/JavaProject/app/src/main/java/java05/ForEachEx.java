package java05;

public class ForEachEx {
    public static void main(String[] args) {
        // int형 배열 정의
        int[] scores = {100, 90, 50, 91, 82};
        
        // 총점을 저장할 sum을 0으로 초기화
        int sum = 0;

        // for-each 문을 사용하여 총점 계산
        for (int score : scores) {
            sum += score;
        }

        // 총점 출력
        System.out.println("총점: " + sum);

        // 배열의 길이로 나누어 평균 계산
        double avg = (double) sum / scores.length;

        // 평균 출력
        System.out.println("평균 : " + avg);
    }
}

