package java06;

import java.util.Arrays;

// interface로 Book class 생성
class Book implements Comparable {
    // 정수형으로 반환
    int price;

    // constructor(생성자)
    public Book(int price) {
        this.price = price;
    }

    // object 비교
    @Override
    public int compareTo(Object o) {
        Book b = (Book) o; // Book으로 casting
        return this.price < b.price ? -1 : (this.price == b.price ? 0 : 1);
    }

    @Override
    public String toString() {
        return "Book [price=" + price + "]";
    }

}

public class BookTest {
    public static void main(String[] args) {
        // 배열 생성
        Book[] books = { new Book(15000), new Book(50000), new Book(20000) };

        System.out.println("정렬 전");
        for (Book book : books) {
            System.out.println(book);
        }

        //java util package
        //sort method를 사용 -> Default인 Ascending 정렬
        Arrays.sort(books);
        System.out.println("정렬 후");
        for (Book book : books) {
            System.out.println(book);
        }
    }
}
