package java06;

// Hotel 클래스 정의
class Hotel {
    // Room Class (내부 Class)
    private class Room {
        int number;
        String client;

        // Room Class의 Constructor
        public Room(int number, String client) {
            this.number = number;
            this.client = client;
        }
    }

    // Hotel Class의 field
    private Room[] rooms = new Room[10];

    // Hotel Class의 method: 방 추가
    public void add(int number, String client) {
        if (number > 0 && number < 11) {
            rooms[number - 1] = new Room(number, client);
        }
    }

    // Hotel Class의 show() method: 방 정보 출력
    public void show() {
        for (Room room : rooms) {
            if (room != null) {
                System.out.println(room.number + "번 방을 " + room.client + "가 예약했습니다.");
            }
        }
    }
}

public class HotelTest {
    public static void main(String[] args) {
        // Hotel Obejct 생성
        Hotel hotel = new Hotel();

        // Hotel object로 방 추가
        hotel.add(5, "호돌이");
        hotel.add(7, "길동이");

        // 방 정보 출력
        hotel.show();
    }
}
