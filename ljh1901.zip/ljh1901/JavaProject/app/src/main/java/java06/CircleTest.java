package java06;


class Circle {
    // Field
    int radius;

    // (int형 radius를 가진)Constructor
    public Circle(int radius) {
        this.radius = radius;
    }

    // 출력 해주는 show() method 정의
    void show() {
        System.out.println("반지름이 " + radius + "인 원이다.");
    }
}

// Circle Class를 inheritance한 ColoredCircle Class 
class ColoredCircle extends Circle {
    // color를 받는 추가 field 정의
    String color;

    // radius와 color를 가진 constructor 정의
    public ColoredCircle(int radius, String color) {
        super(radius);
        this.color = color;
    }

    // method overriding
    void show() {
        System.out.println("반지름이 " + radius + "인 " + color + " 원이다.");
    }
}


public class CircleTest {
    public static void main(String[] args) {
        // Circle Obejct 생성 및 초기화
        Circle c1 = new Circle(5);
        
        // ColoredCircle Object 생성 및 초기화
        ColoredCircle c2 = new ColoredCircle(10, "빨간색");

        // show() method 출력
        c1.show();
        c2.show();
    }
}
