package java06;

// Talkable interface
interface Talkable {
    // method 선언
    void talk();
}

// Korean 클래스: Talkable interface 구현
class Korean implements Talkable {

    // Talkable의 talk() method
    @Override
    public void talk() {
        System.out.println("안녕하세요!");
    }
}

// American Class: Talkable interface override
class American implements Talkable {

    // Talkable 인터페이스의 method override
    @Override
    public void talk() {
        System.out.println("Hello!");
    }
}

public class TalkableTest {

    // speak 메서드: Talkable interface의 object를 parameter로 받아 talk() method 호출
    static void speak(Talkable t) {
        t.talk();
    }

    // 메인 메서드
    public static void main(String[] args) {
        // Korean object 생성 및 speak() 호출
        speak(new Korean());

        // American object 생성 및 speak() 호출
        speak(new American());
    }
}
