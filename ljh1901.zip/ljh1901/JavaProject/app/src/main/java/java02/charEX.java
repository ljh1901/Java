package java02;

public class charEX {
    public static void main(String[] args) {
        char c1 = 'A';
        char c2 = 65; //unicode
        
        char c3 = '가';
        char c4 = 44032; // UTF-8

        System.out.println("c1: "+ c1); // c1: A 
        System.out.println("c2: "+ c2); // c2: A 
        System.out.println("c3: "+ c3); // c3: 가 
        System.out.println("c4: "+ c4); // c4: 가
    }
}
