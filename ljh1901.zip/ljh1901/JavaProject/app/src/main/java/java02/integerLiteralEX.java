package java02;

public class integerLiteralEX {
    public static void main(String[] args) {
        int s1=65; //Decimal 10진법
        int s2=0x41; //hexa 6진법
        int s3=0101; //octal 8진법
        int s4= 0b1000001; //binary(2진법)


        System.out.println("s1: " + s1); // 65
        System.out.println("s2: " + s2); // 65
        System.out.println("s3: " + s3); // 65
        System.out.println("s4: " + s4); // 65
}
}
