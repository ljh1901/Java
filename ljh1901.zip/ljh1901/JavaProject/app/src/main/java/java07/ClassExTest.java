package java07;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class ClassExTest {
    public static void main(String[] args) 
     // main method에서 발생 가능한 예외를 throws로 선언 
    throws ClassNotFoundException, InstantiationException, IllegalAccessException, 
    IllegalArgumentException, InvocationTargetException, ClassNotFoundException, NoSuchFieldException, SecurityException, NoSuchMethodException
    {   // Student Object 생성 및 출력
        Student student = new Student("SmartIT");
        System.out.println(student);
        
        // Class 객체를 이용하여 클래스 정보 가져오기
        Class c1 = Class.forName("java07.Student");
        System.out.println(c1.getName());
        System.out.println(c1.getSimpleName());
        System.out.println(c1.getTypeName());
        System.out.println(c1.getPackage().getName());

        // Constructor 정보 가져오기
        Class[] parameterTypes = { String.class };
        Constructor cons = c1.getConstructor(parameterTypes);
        System.out.println(cons);

        // Constructor를 통해 Object 생성 후 출력
        Object[] initargs = {"Semyung"};
        Student personS = (Student) cons.newInstance(initargs);
        System.out.println(personS);
    }
}
