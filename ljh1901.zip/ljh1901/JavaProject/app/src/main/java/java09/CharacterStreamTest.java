package java09;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class CharacterStreamTest {
    public static void main(String[] args) {
        // Checked Exception => Byte Stream -> Character Stream
        //[5] InputStreamReader / OutputStreamWriter

        try (
            InputStreamReader in = new InputStreamReader(new FileInputStream("./javaproject/app/src/main/java/java09/test.txt"));
            OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream("./javaproject/app/src/main/java/java09/test-out-05.txt"))
            ) {
                int c;
                while ((c = in.read()) != -1) {
                    out.write(c);
                }
                System.out.println("[5] InputStreamReader / OutStreamWriter");

        } catch (Exception e) {
          e.printStackTrace();
        }

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // [6] FileReader / FileWriter
        try (
            FileReader in = new FileReader("./javaproject/app/src/main/java/java09/test06.txt");
            FileWriter out = new FileWriter("./javaproject/app/src/main/java/java09/test-out-06.txt")
        ) {
                            int c;
                while ((c = in.read()) != -1) {
                    out.write(c);
                }
                System.out.println("[6] FileReader / FileWriter");
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

    }
}
