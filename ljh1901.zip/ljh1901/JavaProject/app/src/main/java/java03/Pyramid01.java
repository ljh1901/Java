package java03;

public class Pyramid01 {
    public static void main(String[] args) {
        // [1] 절반의 Tree
        int i, j;
        for(i=0; i<6; i++) {
            for(j=0; j<=i; j++) {
                System.out.print("*"); // 반 Tree를 만들기 위한 *
            }
            System.out.print(" "); // 한쪽의 빈공간만 채우는 로직
            System.out.println(" ");
        }
    }   
}