package java03;

public class TenaryOperatorEx {
    public static void main(String[] args) {
        int score = 75;

        // score가 90보다 크다면, 'A' 등급 else이면, score가 80보다 크다면, 'B' 아니라면 'C' 등급을 설정하는 삼항 연산자
        char grade = (score > 90) ? 'A' : ((score > 80) ? 'B' : 'C');

        System.out.println(score + "점은 "+ grade + "등급입니다.." );


    }
    
}
