package java03;

public class ContinueEx {
    public static void main(String[] args) {
        // i=1부터 i를 1씩 증가
        for(int i=1; i <=10; i++) {
            // 짝수(Even Number)인지 아닌지 검사
            if(i%2 == 0) {
                continue;
            }
            //Odd Number 출력
            System.out.print(i + " ");
        }
    }
    
}
