package java03;

public class PyramidTestEx {
    public static void main(String[] args) {
        System.out.println("       *     ");
        System.out.println("      ***     ");
        System.out.println("     *****     ");
        System.out.println("    *******     ");
        System.out.println("   *********     ");
    }
    
}
