package java03;

public class IfElseIfElseEx {
public static void main(String[] args) {
    int score = 80; //int score; score = 80;
    if(score >= 95){
        System.out.println("당신의 학점은 A+ 입니다..");
    }
    else if(score >= 90){
        System.out.println("당신의 학점은 A0 입니다..");
    }
    else if(score >= 85){
        System.out.println("당신의 학점은 B+ 입니다..");
    }
    else if(score >= 80){
        System.out.println("당신의 학점은 B0 입니다..");
    }
    else if(score >= 75){
        System.out.println("당신의 학점은 C+ 입니다..");
    }
    else if(score >= 70){
        System.out.println("당신의 학점은 C0 입니다..");
    }
    else if(score >= 65){
        System.out.println("당신의 학점은 D+ 입니다..");
    }
    else if(score >= 60){
        System.out.println("당신의 학점은 D0 입니다..");
    }
    else{
    System.out.println("당신의 학점은 F 입니다..");
      }
     }
    }