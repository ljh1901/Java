package java03;

public class Pyramid02 {
    public static void main(String[] args) {
        int i, j, k;
        int num =7;

        // [0] 몇단의 Tree를 만들 것인가?
        for(i=0; i<num; i++) {
            //[1] 빈공간을 채우는 로직
            for(j=0; j<num-i; j++) {
                System.out.print(" ");
            }
            // [2] 완성된 Tree 만들기 위한 *
            for(k=0;k<i*2+1;k++) {
                System.out.print("*");
            }
                System.out.println();
            }
        }
    }   
