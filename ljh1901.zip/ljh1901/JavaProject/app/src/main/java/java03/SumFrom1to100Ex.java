package java03;

public class SumFrom1to100Ex {
    public static void main(String[] args) {
        int sum = 0;
        int i;
        //i=1부터 i를 1씩 증가시켜 1~100까지의 합을 구함
        for(i =1; i <=100; i++){
            sum += i;
        }
        System.out.println("1~" + (i-1) + "합: "+ sum);
    }
    
}
