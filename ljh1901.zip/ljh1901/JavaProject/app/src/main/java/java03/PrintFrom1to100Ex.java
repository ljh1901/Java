package java03;

public class PrintFrom1to100Ex {
    public static void main(String[] args) {
        // i=1부터 i를 1씩 증가 시키면서 1~100을 출력
        for (int i=1; i<=100; i++) {
            System.out.print(i + " ");
        }
        }
    }
