package java07_Review;

import java.util.Random;

public class RandomEx {
    public static void main(String[] args) {
        // Random object 생성
        Random random = new Random();

        // 1부터 45까지의 random 5개를 생성
        for (int i = 0; i <5; i++) {
            System.out.print(random.nextInt(45) + 1 + " ");

            
        }
    }
}
