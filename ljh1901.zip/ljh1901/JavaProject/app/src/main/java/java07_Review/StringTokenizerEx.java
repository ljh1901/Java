package java07_Review;

import java.util.StringTokenizer;

public class StringTokenizerEx {
    public static void main(String[] args) {
        // 문자열 초기화
        String s = "of the people, by the people, for the people";

        // StringTokenizer object 생성 및 ,와 공백으로 구분
        StringTokenizer st = new StringTokenizer(s, ", ");

        // 토큰 개수 출력
        System.out.println(st.countTokens());

        // 모든 토큰 출력
        while(st.hasMoreTokens()) {
            System.out.print("[" + st.nextToken() + "] ");
        }
    }
}
