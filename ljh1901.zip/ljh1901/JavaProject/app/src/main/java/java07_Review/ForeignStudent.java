package java07_Review;
// Student를 inheritance 받은 ForeignStudent Class
public class ForeignStudent extends Student {
    String nationality;
    // 이름, 나이, 학번, 국적
    public ForeignStudent(String name, int age, int number, String nationality) {
        super(name, age, number);
        this.nationality = nationality;
    }
    //getter method
    public String getNationality() {
        return nationality;
    }
    //setter method
    public void setNationality(String nationality) {
        this.nationality = nationality;
    }
    public String show() {
        return "외국학생[이름 : " + getName() + ", 나이 : " + getAge() + ", 학번 : " + getNumber() + ", 국적 : " + getNationality() + "]";
    }
    
}
