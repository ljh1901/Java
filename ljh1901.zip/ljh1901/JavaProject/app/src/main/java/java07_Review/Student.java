package java07_Review;

public class Student extends Person {
    int number;

    public Student(String name, int age, int number) {
        super(name, age);
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String show() {
        return "학생[이름: " + getName() + ", 나이: " + getAge() + ", 학번: " + number + "]";
    }
}
