package java13.threadtest;

// [2] Runnable Interface를 구현하는 방법 (o)

class NewRunnable implements Runnable {
    private int number = 0;


    
    
    public NewRunnable(int n) {
        System.out.println("Thread-0" + " : Thread 시작");
        this.number = n;
    }
    
    @Override
    public void run() {
        int i = 0;

        while (i < number) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}
            System.out.println("Thread-0 : " + i + "\n");
            i++;
        }
        System.out.println("Thread-0" + ": Thread 종료");   
    }
}




public class NewRunnableTest {
public static void main(String[] args) {
    
    // (1) object 생성(0~9까지)
    // NewRunnable nr = new NewRunnable(10);

    // (2) java.lang package의 Thread를 불러와 object 생성.
    // Thread t = new Thread(nr);

    // (3) standby statement / start() / ready statement / run() / running statement
    // t.start();
    new Thread(new NewRunnable(10)).start();
}
}
