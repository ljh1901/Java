package java13.functionaltest;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;


public class FunctionalTest {
    public static void main(String[] args) {
        System.out.println("[1] Anonymous Class");
        /**
         * ; (semicolon) 사용법
         * 1) Statement 뒤에
         * 2) Anonymous Class 뒤에
         * 3) enum 뒤에
         * 4) SQL 뒤에
         */

        // Wrapper Class

        // Supplier<Integer> as = new Supplier<Integer>() {

        //     @Override
        //     public Integer get() {
        //         return (int) (Math.random() * 10);
        //     }
        // };

        // System.out.println(as.get());
        // System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        System.out.println("[2] Consumer Interface");
        Consumer<Integer> c = i -> System.out.println(i);
        c.accept(33);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        System.out.println("[3] Supplier Interface");
        Supplier<Integer> s = () -> (int) (Math.random() * 10);
        System.out.println(s.get());
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        System.out.println("[4] Function interface");
        Function<Integer, Double> f = i -> i / 2.0;
        System.out.println(f.apply(33));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        System.out.println("[5] Predicate Interface");
        Predicate<Integer> p1 = i -> i == 33;
        System.out.println(p1.test(33));
        Predicate<Integer> p2 = i -> i < 10; // Sourcekit Evolution
        Predicate<Integer> p3 = i -> i < 20;
        Predicate<Integer> p4 = p1.or(p2.negate().and(p3));
        System.out.println(p4.test(10));
        Predicate<String> p5 = Predicate.isEqual("SmartIT");
        System.out.println(p5.test("SmartIT"));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        System.out.println("[6] UnaryOperator Interface");
        UnaryOperator<Integer> u = i -> i * 10;
        System.out.println(u.apply(33));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        System.out.println("[7] BiFunction Interface");
        BiFunction<Integer, Integer, Double> bf = (i1, i2) -> i1 / (double) i2;
        System.out.println(bf.apply(33, 2));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

    }
}
