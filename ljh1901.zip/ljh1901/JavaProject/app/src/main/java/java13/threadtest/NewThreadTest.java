package java13.threadtest;

// [1] Thread Class를 Inheritance 하는 방법 (x)
class NewThread extends Thread {
    private int number = 0;

    public NewThread(int n) {
        System.out.println("Thread-0" + " : Thread 시작");
        this.number = n;
    }

    @Override
    public void run() {
        int i = 0;

        while (i < number) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
            System.out.println("Thread-0 : " + i + "\n");
            i++;
        }
        System.out.println("Thread-0" + ": Thread 종료");
    }
}

public class NewThreadTest {
    public static void main(String[] args) {

        // (1) object 생성
        // NewThread nt = new NewThread(10);

        // (2) Threadclass inheritance
        // nt.start();

        new NewThread(10).start();
    }
}
