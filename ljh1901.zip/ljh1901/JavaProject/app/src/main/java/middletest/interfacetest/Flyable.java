package middletest.interfacetest;

public interface Flyable {
    void speed();
    void height();
}
