package middletest.prob04;

public class Radio extends Controller {
    public Radio(boolean power) {
        super(power);
    }

    String getName() {
        return "라디오";
    }
}
