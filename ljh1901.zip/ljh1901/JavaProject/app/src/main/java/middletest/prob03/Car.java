package middletest.prob03;

public class Car extends Vehicle {

    int displacement;
    int geers;

    // Car 클래스의 constructor
    public Car(String color, int speed, int displacement, int geers) {
        // 부모 클래스의 color와 speed
        super(color, speed);
        this.displacement = displacement;
        this.geers = geers;
    }

    // Overriding
    @Override
    void show() {
        System.out.println("자동차 색상: " + color );
        System.out.println("자동차 속도: " + speed ); 
        System.out.println("자동차 배기량: " + displacement);
        System.out.println("자동차 기어 단수: " + geers);
    }
}
