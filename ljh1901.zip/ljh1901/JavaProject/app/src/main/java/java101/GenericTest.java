package java101;

public class GenericTest {
    public static void main(String[] args) {
        // Object 생성
        Book b1 = new Book("Java Generics", "세명출판사");
        Book b2 = new Book("Spring Framework", "정보통신출판사");
        Book b3 = new Book("Spring Boot", "스마트출판사");

        Cart<Book> cart = new Cart<Book>(); // Type Argument
        //add() method를 이용해 cart에 책을 추가 
        cart.add(b1);
        cart.add(b2);
        cart.add(b3);

        //cart에 담긴 책을 출력
        cart.printAllItems();
    }
}
