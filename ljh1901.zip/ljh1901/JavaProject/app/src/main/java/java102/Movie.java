package java102;

//Content를 interface하는 Movie Class
public class Movie implements Content {

    private String title;
    private String writer;
    
    public Movie(String title) {
        this.title = title;
    }
    
    public Movie(String title, String writer) {
        this.title = title;
        this.writer = writer;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

}
