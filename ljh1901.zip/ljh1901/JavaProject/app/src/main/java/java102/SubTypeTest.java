package java102;

import java.util.ArrayList;
import java.util.List;

public class SubTypeTest {
    public static void main(String[] args) {

        // List<Content> musics = new ArrayList<Music>();
        List<Music> musicList = new ArrayList<Music> ();
        musicList.add(new Music("스마트IT 학부송"));
        musicList.add(new Music("세명대 축하송"));
        
        Player.play(musicList);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        Player.addRecommendedContent(musicList);
        Player.play(musicList);
    }
}
