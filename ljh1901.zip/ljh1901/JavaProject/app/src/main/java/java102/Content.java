package java102;

public interface Content {
    public abstract String getTitle();
}
