package java102;

import java.util.List;

public class Player {

    // [1] Producer Extends (read)
    public static void play(List<? extends Content> playList) { // Upper Bound
        for (Content content : playList) {
            System.out.println("재생: " + content.getTitle());
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    // [2] Consumer Super (write)
    public static void addRecommendedContent(List<? super Music> playList) {
        Music music = new Music("chatGPT4 Song!!");
        playList.add(music);

        // playList.add(new Movie("Star Wars"));
    }
}
