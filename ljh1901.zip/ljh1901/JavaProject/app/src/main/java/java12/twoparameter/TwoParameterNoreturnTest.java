package java12.twoparameter;

public class TwoParameterNoreturnTest {
    public static void main(String[] args) {
        
    // [2] Two Parameter, Noreturn
    Calculate c;

    c = (x, y) -> System.out.println(x+y);
    c.cal(9, 3);

    c = (x, y) -> System.out.println(x-y);
    c.cal(9, 3);
    
    c = (x, y) -> System.out.println(x*y);
    c.cal(9, 3);
    
    c = (x, y) -> System.out.println(x/y);
    c.cal(10, 3);
}
}
