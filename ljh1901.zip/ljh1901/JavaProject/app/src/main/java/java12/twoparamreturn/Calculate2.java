package java12.twoparamreturn;
@FunctionalInterface
public interface Calculate2 {
    int cal(int a, int b);
    
}
