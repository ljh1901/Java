package java12.twoparameter;
@FunctionalInterface
public interface Calculate {
    void cal(int a, int b);
}
