package java12.lamdagenerics;

// Generic을 사용, 다양한 Type의 계산을 수행하는 functional interface

@FunctionalInterface
public interface Calculate3<T> {

    // 두 개의 인자를 받아 계산을 수행하는 method
    T cal(T a, T b);
}

