package java12;

public class NoParameterReturnTest {
    public static void main(String[] args) {
        // [1] parameter one, void type(no return)

        Printable p;

        // (1) 줄임 표현이 없음
        p = (String s) -> {System.out.println(s);}; 
        p.print("환영합니다..Lamda Expression[1] 과정입니다..");

        // (2) {} 생략
        p = (String s) -> System.out.println(s);
        p.print("환영합니다..Lamda Expression[2] 과정입니다..");

        // (3) parameter type를 생략
        p = (s) -> System.out.println(s);
        p.print("환영합니다..Lamda Expression[3] 과정입니다..");

        // (4) 하나의 parameter만 있을 경우 ()을 생략
        p = s -> System.out.println(s);
        p.print("환영합니다..Lamda Expression[4] 과정입니다..");

    }



    
}
