package java12.oneparamreturn;

@FunctionalInterface
public interface LengthCount {
    int len(String s);
}
