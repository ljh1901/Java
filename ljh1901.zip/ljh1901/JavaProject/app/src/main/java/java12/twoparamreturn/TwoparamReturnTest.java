package java12.twoparamreturn;

public class TwoparamReturnTest {
    public static void main(String[] args) {
        // [3] Two Parameter, Return Type
        Calculate2 c;

        // (1) Object를 생성하고, 이를 이용하여, 두 수의 합을 계산
        c = (x, y) -> {return x + y;};
        System.out.println(c.cal(9,3));

        // (2) {} 에 return문만 있을 경우, { return }; 을 생략
        c = (x, y) -> x + y;
        System.out.println(c.cal(9,3));
    }
}
