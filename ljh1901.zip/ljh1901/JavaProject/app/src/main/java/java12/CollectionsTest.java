package java12;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollectionsTest {
    public static void main(String[] args) {
        String[] fruits = { "포도", "수박", "사과", "키위", "망고"};
        List<String> list = Arrays.asList(fruits); // Imuterable Data type

        System.out.println(list);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        Collections.sort(list, Collections.reverseOrder()); //descending
        System.out.println(list);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        Collections.reverse(list); //ascending
        System.out.println(list); 
        
    }
}
