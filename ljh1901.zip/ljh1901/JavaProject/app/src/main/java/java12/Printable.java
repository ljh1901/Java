package java12;
@FunctionalInterface
public interface Printable {
    void print(String s);
}
