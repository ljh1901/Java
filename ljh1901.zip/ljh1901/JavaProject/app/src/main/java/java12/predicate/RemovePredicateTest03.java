package java12.predicate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class RemovePredicateTest03 {
    public static void main(String[] args) {
        List<Integer> ls1 = Arrays.asList(1, -2, 3, -4, 5);
        ls1 = new ArrayList<>(ls1);

        List<Double> ls2 = Arrays.asList(-1.1, 2.2, 3.3, -4.4, 5.5);
        ls2 = new ArrayList<>(ls2);

        Predicate<Number> p = n -> n.doubleValue() < 0.0;

        //Collection.removeIf가 있고 super가 됐기 때문에 Predicate도 됨.
        ls1.removeIf(p);
        ls2.removeIf(p);

        System.out.println(ls1); // [1, 3, 5]
        System.out.println(ls2); // [2.2, 3.3, 5.5]

    }
}
