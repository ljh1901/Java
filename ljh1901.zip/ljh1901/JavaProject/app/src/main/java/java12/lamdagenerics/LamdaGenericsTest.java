package java12.lamdagenerics;

public class LamdaGenericsTest {
    public static void main(String[] args) {
        // [4] Lamda Generics
        //Generic의 int형 값을 받아 Lamda식으로 x+y 수행
        Calculate3<Integer> ci = (x, y) -> x+y;
        System.out.println(ci.cal(9,3));

        //Generic의 Double형 값을 받아 Lamda식으로 x+y 수행
        Calculate3<Double> cd = (x, y) -> x+y;
        System.out.println(cd.cal(33.33, 22.22)); 
    }
}
