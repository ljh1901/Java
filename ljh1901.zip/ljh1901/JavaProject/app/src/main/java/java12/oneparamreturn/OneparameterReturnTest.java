package java12.oneparamreturn;

public class OneparameterReturnTest {
    public static void main(String[] args) {
        // [3] One parameter, Return Type
        LengthCount lc = s -> s.length();
        System.out.println(lc.len("School of SmartIT!!!"));
    }

}
