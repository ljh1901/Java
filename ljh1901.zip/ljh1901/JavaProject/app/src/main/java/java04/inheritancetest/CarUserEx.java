package java04.inheritancetest;

public class CarUserEx {
    public static void main(String[] args) {

        // [1] Car object 생성
        Car myCar = new Car();

        // [2] Tire object 장착
        myCar.tire = new HankookTire();

        // [3] Kumho Tire 장착
        myCar.tire = new KumhoTire();
        myCar.run();

    }

}
