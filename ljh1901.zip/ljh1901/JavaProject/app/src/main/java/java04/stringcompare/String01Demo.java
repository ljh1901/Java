package java04.stringcompare;

public class String01Demo {
    public static void main(String[] args) {
        // 문자열 Literal을 사용하여 문자열 생성
        String s1 = "Hi, java!";
        String s2 = "Hi, java!";

        // 문자열 Object 생성
        String s3 = new String("Hi, java!");
        String s4 = new String("Hi, java!");

        // String Literal을 사용, 같은 문자열이 이미 Constant Pool에 존재
        System.out.println(s1 == s2); // true

        // new 키워드를 사용하여 새로운 객체를 생성하면 새로운 Object가 생성
        System.out.println(s3 == s4); // false
    }
}
