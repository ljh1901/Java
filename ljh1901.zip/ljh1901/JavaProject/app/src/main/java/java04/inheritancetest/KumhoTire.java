package java04.inheritancetest;

public class KumhoTire extends Tire {
    // KumhoTire 클래스에서 상속받은 Tire 클래스의 roll method를 Override하여 구현 method
    @Override
    public void roll() {
        System.out.println("금호타이어가 굴러갑니다..");
    }
}
