package java04.interfacetest;

public class CarUserEx02 {
    public static void main(String[] args) {
         // [1] Car object 생성
         Car myCar = new Car();

         // [2] Tire object 장착
         myCar.tire1 = new HankookTire();
         myCar.run();

         // [3] Kumho Tire 장착
         myCar.tire2 = new KumhoTire();
         myCar.tire3 = new NexsenTire();
    }
}
