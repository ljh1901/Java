package java04.interfacetest;

public class NexsenTire implements Tire {
    @Override
    public void roll() {
        System.out.println("넥센 타이어가 굴러갑니다...");
    }

}
