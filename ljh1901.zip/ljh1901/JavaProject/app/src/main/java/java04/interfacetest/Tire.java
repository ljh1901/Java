package java04.interfacetest;

public interface Tire {
    //abstract method
    void roll();
}
