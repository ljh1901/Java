package java04.interfacetest;

// Test Class 정의
public class Test {
    // Field 정의
    private int id; // (정수형)
    private String name; // (문자열)
    private String email;
    private String address;
    
    // Getter 및 Setter 메서드 정의

    // id Field의 Getter 메서드
    public int getId() {
        return id;
    }

    // id Field의 Setter 메서드
    public void setId(int id) {
        this.id = id;
    }

    // name Field의 Getter 메서드
    public String getName() {
        return name;
    }

    // name Field의 Setter 메서드
    public void setName(String name) {
        this.name = name;
    }

    // [5] email Field의 Getter 메서드
    public String getEmail() {
        return email;
    }

    // [6] email Field의 Setter 메서드
    public void setEmail(String email) {
        this.email = email;
    }

    // [7] address Field의 Getter 메서드
    public String getAddress() {
        return address;
    }

    // [8] address Field의 Setter 메서드
    public void setAddress(String address) {
        this.address = address;
    }
}
