package java04.interfacetest;

// Car Class 정의
public class Car {
    // [1] Tire interface를 구현하고, Object 생성
    Tire tire1 = new HankookTire();
    Tire tire2 = new KumhoTire();
    Tire tire3 = new NexsenTire();

    // [2] run method 생성
    void run() {
        tire1.roll(); // tire1 굴리기
        tire2.roll(); // tire2 굴리기
        tire3.roll(); // tire3 굴리기
    }
}
