package java04.inheritancetest;

public class Tire {
    // method 선언
    public void roll() {
        System.out.println("타이어가 굴러갑니다..");
    }
}
