package java04.inheritancetest;

public class Car {
    // field
public Tire tire;
    // method
    public void run() {
        //tire field에 대입된 object의 roll() method 호출
        tire.roll();
    }
}
