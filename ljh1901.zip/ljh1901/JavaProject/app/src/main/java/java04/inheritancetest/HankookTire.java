package java04.inheritancetest;

// Tire의 Child class 정의(inheritance)
// Super class: Tire class
public class HankookTire extends Tire {

    // Tire를 장착하는 roll method 정의
    @Override
    public void roll() {
        System.out.println("한국타이어가 굴러갑니다..");
    }
    
}
