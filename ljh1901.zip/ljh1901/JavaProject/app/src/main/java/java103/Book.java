package java103;

public class Book {
    private String title;
    private String publisher;

    public Book(String title, String publisher) {
        this.title = title;
        this.publisher = publisher;
    }
    //title의 getter & setter
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    //publisher의 getter & setter
    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    @Override
    public String toString() {
        return "Book [title=" + title + ", publisher=" + publisher + "]";
    }
}
