package java103;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Cart {
    private List<Book> books;

    public Cart() {
        books = new ArrayList<>();
    }

    // -Cart 책 추가-
    public void add(Book book) {
        books.add(book);
    }

    // -Cart에 담을 책 찾기-
    public void add(int index, Book book) {
        books.add(index, book);
    }

    // -중복된 책 검사-
    public boolean checkForDuplicate(Book book) {
        return books.contains(book);
    }

    public List<Book> getAllBooks() {
        return books;
    }

    public Book getBook(int index) {
        return books.get(index);
    }

    public static void printAllBooksWithFor(List<Book> books) {
        // [1] For i로 출력
        System.out.println("[1] for i 방법으로 출력");
        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            System.out.println(book);
        }
    }

    public static void printAllBooksWithIterator(List<Book> books) {
        // [2] Iterator
        System.out.println("[2] Iterator 방법으로 출력");
        for (Iterator<Book> it = books.iterator(); it.hasNext();) {
            System.out.println(it.next());
        }
    }

    public static void printAllBooksWithListIterator(List<Book> books) {
        // [3] List Iterator 방법으로 출력 (강력 추천)
        System.out.println("[3] List Iterator 방법으로 출력");

        ListIterator<Book> it= books.listIterator();

        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }

}
