package java103;

import java.util.List;

public class ListTest {
    public static void main(String[] args) {
        Book b1 = new Book("Java List", "리스트 출판사");
        Book b2 = new Book("Java Lamda Expression", "람다 출판사");
        Book b3 = new Book("Java Stream", "스트림 출판사");

        Cart cart = new Cart();
        cart.add(b1);
        cart.add(b3);
        cart.add(1, b2);

        // System.out.println(cart.checkForDuplicate(b3));
        Book b4 = new Book("Spring Boot", "스프링 출판사");
        // System.out.println(cart.checkForDuplicate(b4));

        // System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // System.out.println(cart.getBook(1));

        // getAllBooks() - b4는 카트에 추가X
        List<Book> books = cart.getAllBooks();
        System.out.println(cart.getAllBooks());

        // [1] for i
        Cart.printAllBooksWithFor(books);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // [2] Iterator
        Cart.printAllBooksWithIterator(books);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // [3] List Iterator
        Cart.printAllBooksWithListIterator(books);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

    }
}
