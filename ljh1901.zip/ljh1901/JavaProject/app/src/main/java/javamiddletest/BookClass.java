package javamiddletest;
import java.util.Arrays;

class Book implements Comparable {
    // int type의 price field
    int price;

    // constructor(생성자)
    public Book(int price) {
        this.price = price;
    }

    // object 비교
    @Override
    public int compareTo(Object obj) {
        // Book으로 casting
        Book book = (Book) obj;
        /*
         this.price가 book.price보다 작으면, -1을 반환.
         만약 this.price가 book.price와 같으면, 0을 반환.
         만약 this.price가 book.price보다 크면, 1을 반환.
         책의 리스트를 가격을 기준으로 오름차순으로 정렬.
         */
        return this.price < book.price ? -1 : (this.price == book.price ? 0 : 1);
    }

    @Override
    public String toString() {
        return "Book [cost=" + price + "]";
    }
}

public class BookClass {
    public static void main(String[] args) {
        // 배열 생성
        Book[] books = { new Book(18000), new Book(35000), new Book(23000) };

        System.out.println("[Before Sorting]");
        for (Book book : books) {
            System.out.println(book);
        }
        // 줄바꿈
        System.out.println();

        /* 
        java util package의 Array
        Arrays books를 정렬하기 위해 Arrays.sort(books) 호출
        */
        Arrays.sort(books); 
        System.out.println("[After Sorting]");
        // 이 루프 내에서 'book' 변수를 사용하여 각 Book 객체에 접근할 수 있습니다
        for (Book book : books) {
            System.out.println(book);
        }
    }
}