package javamiddletest;

/*  Controller abstract class
    부모 클래스 정의
*/
abstract class Controller {
    boolean power;

    public Controller(boolean power) {
        this.power = power;
    }

    void show() {
        if (power == true) {
            System.out.println(getName() + "가 켜졌습니다.");
        } 
        else {
            System.out.println(getName() + "가 꺼졌습니다.");
        }
    }

    // 추상 method getName
    abstract String getName();
}

// child class인 TV(Controller class inheritance)
class TV extends Controller {
    public TV(boolean power) {
        super(power);
    }

    @Override
    String getName() {
        return "TV";
    }
}

// child class인 Radio(Controller class inheritance)
class Radio extends Controller {
    public Radio(boolean power) {
        super(power);
    }

    @Override
    String getName() {
        return "라디오";
    }
}

// Controoler Test
public class ControllerTest {
    public static void main(String[] args) {
        /*
         * Controller의 배열 c를 생성하고, 배열 안에 new operation Type의
         * TV(true)는 TV 클래스의 Constructor를 호출하여 전원을 켠 TV object와,
         * Radio(false)는 Radio 클래스의 Constructor를 호출하여 전원을 끈 Radio 객체를 생성
         */
        Controller[] c = { new TV(false), new Radio(true) };
        // Controller 타입의 controller 변수를 반복 요소에 할당
        for (Controller controller : c) {
            controller.show();
        }
    }
}
