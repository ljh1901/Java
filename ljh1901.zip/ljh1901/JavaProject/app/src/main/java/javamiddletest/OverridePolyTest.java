package javamiddletest;

// 부모 클래스
class Vehicle {
    String color;
    int speed;

    // Vehicle 클래스의 constructor
    public Vehicle(String color, int speed) {
        this.color = color;
        this.speed = speed;
    }

    public void show() {
        System.out.println("vehicle/" + "color(색상): " + color + ", speed(속도): " + speed);
    }
}

// 자식 클래스
class Car extends Vehicle {
    int displacement;
    int gears;

    // Car 클래스의 constructor
    public Car(String color, int speed, int displacement, int gears) {
        // 부모 클래스의 color와 speed
        super(color, speed);
        this.displacement = displacement;
        this.gears = gears;
    }

    // Overriding
    @Override
    public void show() {
        super.show(); // 부모 클래스의 show() method를 실행
        System.out.println(
                "Car/" + "color(색상): " + color + ", speed(속도): " + speed + ", displacement(배기량): " + displacement
                        + ", Gears(기어): " + gears);
    }
}

public class OverridePolyTest {
    public static void main(String[] args) {
        // Car object 생성
        Car car = new Car("white", 300, 1500, 6);
        // Car 클래스의 show() method 호출
        car.show();
        System.out.println();
        /*
         * Car object를 Vehicle 타입으로 참조하여 Vehicle 클래스의 show() method 호출
         * polymorphism을 통해 Car 클래스의 show() 메서드가 호출
         */
        Vehicle vehicle = car;
        vehicle.show();
    }
}