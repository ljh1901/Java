package java01; // 1) main 외부에 올 수 있음

import java.lang.*; //2) main 외부에 올 수 있음

// Comment (주석)
// Ctrl + /

// (1) 한줄 주석

/*  (2) 여러줄 주석
*
*/

/** (3) java Documentation 
 * 
*/


// 3) Outer Class - main 외부에 올 수 있음
class Smart {

}



public class HelloWorld {
    public static void main(String[] args) {
    // 1) fields

    // 2) methods

    // 3) Constructor(Default Constructor / Constructor)

    // 4) inner class

        System.out.println("자바 언어 환영합니다..");
    }
}
