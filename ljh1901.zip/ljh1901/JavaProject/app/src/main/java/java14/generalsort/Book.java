package java14.generalsort;

public class Book implements Comparable<Book> {
    private int no;
    private String title;

    public Book(int no, String title) {
        this.no = no;
        this.title = title;
    }
    
    public int getNo() {
        return no;
    }

    public String getTitle() {
        return title;
    }

    
    // no 내림차순으로, title 오름차순으로 정렬
    @Override
    public int compareTo(Book book) {
        int result = Integer.valueOf(no).compareTo(book.getNo()) * -1;
        if(result == 0)
            result = title.compareTo(book.title);
        return result;
    }

    @Override
    public String toString() {
        return "Book [no=" + no + ", title=" + title + "]";
    }
    
    
}
