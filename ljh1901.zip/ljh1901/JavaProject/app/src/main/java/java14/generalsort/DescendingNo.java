package java14.generalsort;

// Book 클래스를 비교하는 Comparator

import java.util.Comparator;

public class DescendingNo implements Comparator<Book> {

    // Book 객체들을 번호에 대해 내림차순으로 정렬하는 compare() method
    @Override
    public int compare(Book b1, Book b2) {
        // 번호 비교
        int result = Integer.valueOf(b1.getNo()).compareTo(b2.getNo());
        
        // 번호가 같을 경우 title을 기준으로 정렬
        if (result == 0)
            result = b1.getTitle().compareTo(b2.getTitle());
        
       
        return result;
    }
}

