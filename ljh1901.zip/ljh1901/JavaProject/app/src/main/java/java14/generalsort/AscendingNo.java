package java14.generalsort;

import java.util.Comparator;

public class AscendingNo implements Comparator<Book> {

    @Override
    public int compare(Book b1, Book b2) {
        //책번호(no)를 기준으로 오름차순 정렬
        int result = Integer.valueOf(b1.getNo()).compareTo(b2.getNo());
        if (result == 0)
            result = b1.getTitle().compareTo(b2.getTitle());
        return result;

    }

    
}
