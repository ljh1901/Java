package java15;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamTest03 {
    public static void main(String[] args) {
        // int[] -> IntStream -> Stream<Integer> -> Integer[]
        int[] arr = {11, 33, 66, 77, 99};

        // (1) int[] -> IntStream  
        IntStream stream = Arrays.stream(arr);


        // (2) IntStream -> Stream<Integer>
        Stream<Integer> boxed = stream.boxed();

        // (3) Stream<Integer> -> Integer[] ===> Method Reference
        Integer[] result = boxed.toArray(Integer[]::new);

        System.out.println(Arrays.toString(result));

        System.out.println(result.getClass().getTypeName());
        System.out.println(result.getClass().getSimpleName());

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // (4) (1)+(2)+(3) 한줄로 표현
        Integer[] smartOne = Arrays.stream(arr)
                                   .boxed()
                                   .toArray(Integer[]::new);
                                   
        for (Integer smu : smartOne) {
            System.out.println(smu);
        }
        
        System.out.println(smartOne.getClass().getTypeName());
        System.out.println(smartOne.getClass().getSimpleName());

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }
}
