package java15;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.Iterator;

public class StreamTest01 {
    public static void main(String[] args) {
        // int type(primitive data type)의 형태를 가진 array에
        // (1) 중복제거, (2) Descending 처리, (3) List Collection Type
        int[] arr = { 2, 3, 33, 8, 3, 2, 55, 11 };
        List<Integer> lists = new ArrayList<>(); //List 배열
        Set<Integer> sets = new HashSet<>(); //Generic형태

        // [1] Stream을 사용하지 않을 경우
        // (1) 중복 제거
        for (int i = 0; i < arr.length; i++) {
            sets.add(arr[i]);
        }

        // for (int i = 0; i < arr.length; i++) {
        //     lists.add(arr[i]);
        // }
        
        // (2) List Collection Type을 변환
        Iterator<Integer> itr = sets.iterator();
        for (int i = 0; itr.hasNext(); i++) {
            lists.add(itr.next());
        }

        // (3) Descending 처리
        lists.sort(Comparator.reverseOrder());

        System.out.println("[1] Stream을 사용하지 않을 경우 출력: " + lists.toString());


        // [2] Stream을 사용 사용하는 경우
        // (1) boxed() method : IntStream과 같이 primitive data type에 대한 Stream지원을 하는 
        // Class Type (intStream -> Stream<Integer>)으로 mapping 전송으로 실행 가능한 기능의 method

        // (2) distinct() method : 중복 요소 제거를 위한 method, 중복된 요소를 제거하고, 새로운 스트림을 생성

        // (3) sorted(Comparator.reverseOrder()) method : Comparator.reverseOrder()는 역순으로 비교하는 Comparator를 생성하고,
        // 이를 정렬 시켜주는 method ->Descending 내림차순으로 정렬을 해줌.

        // (4) .collect(Collectors.toList()) method: Collector interface인 Collectors.toList()를 사용하여 스트림의 요소를 List로 가져온 후,
        // toList()는 스트림의 요소를 리스트로 변환하는 데에 사용되는 method
        System.out.println("[2] Stream을 사용하는 경우 출력: " + 
            Arrays.stream(arr)
                  .boxed()
                  .distinct()
                  .sorted(Comparator.reverseOrder())
                  .collect(Collectors.toList())
        );


    }
}
