package java15;

import java.util.ArrayList;
import java.util.List;

public class StreamTest02 {
    public static void main(String[] args) {
        
        // [1] ArrayList<Integer>를 int Array로 mapping
        List<Integer> lists = new ArrayList<>();
        lists.add(22);
        lists.add(55);
        lists.add(99);

        // (1) 방법 (for i)
        int[] arr1 = new int[lists.size()];
        for (int i = 0; i < lists.size(); i++) {
            arr1[i] = lists.get(i).intValue();
            System.out.println(arr1[i]);     
         }
         System.out.println(arr1.getClass().getTypeName());

         System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

         // [2] 방법: Lamda Expression
         // mapToInt() method: 기존의 요소를 int로 매핑하여 IntStream을 생성, 
         // 기본 자료형 int로 변환하거나 특정 Field를 추출하는데 사용되는 method

         // toArray() method: 스트림의 요소를 배열로 변환하는 method
         int[] arr2 = lists.stream()
                           .mapToInt(i->i)
                           .toArray();

         for (int rv : arr2) {
            System.out.println(rv);
         }
         System.out.println(arr2.getClass().getTypeName());

         System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

         // [3] 방법: Method Reference
         int[] arr3 = lists.stream()
                           .mapToInt(Integer::intValue) //Wrapper Class
                           .toArray();

         for (int rv : arr3) {
            System.out.println(rv);
         }
         System.out.println(arr3.getClass().getTypeName());

         System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

         // [4] 방법: filtering을 적용
         
         //  filter method: 스트림에서 특정 조건을 만족하는 요소들만 필터링하는 method 
         // 여기서는 null이 아닌 요소들을 선택
         int[] arr4 = lists.stream()
                           .filter(i -> i != null)
                           .mapToInt(i -> i)
                           .toArray();

         for (int i : arr4) {
            System.out.println(i);
         }
         
        System.out.println(arr4.getClass().getTypeName());

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }
}
