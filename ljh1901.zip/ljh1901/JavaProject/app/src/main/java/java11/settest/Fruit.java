package java11.settest;

public class Fruit {
    private String name;

    // Constructor
    public Fruit(String name) {
        this.name = name;
    }

    // 과일이름을 toString method로 생성
    @Override
    public String toString() {
        return String.format("Fruit(%s)", name);
    }
    
    // equals() method를 사용하여, boolean 값으로 Object의 동등성 비교
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Fruit other = (Fruit) obj;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        return true;
    }

    // object의 hashcode를 반환하는 메서드
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }
}
