package java11.maptest;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;

public class MapTest {
    public static void main(String[] args) {
        System.out.println("[1] SmartIT A반");
        Map<String, String> classA = new HashMap<>();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        classA.put("A1", "Java Skill");
        classA.put("A2", "Spring Skill");
        classA.put("A3", "Python Skill");
        classA.put("A4", "Java Skill");
        classA.put("A5", "Java Skill");
        classA.put("A6", "DataBase Skill");

        // [1] Map.Enrty<String, String>
        for (Map.Entry<String, String> rv : classA.entrySet()) {
            System.out.println("이름: " + rv.getKey() + " " + "\tSkill: " + rv.getValue());
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        System.out.println("[2] SmartIT B반");
        Map<String, String> classB = new HashMap<>();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        classB.put("B1", "Java Skill");
        classB.put("B2", "Python Skill");
        classB.put("B3", "Java Skill");
        classB.put("B4", "Android Skill");
        classB.put("B5", "IOS Skill");
        classB.put("B6", "Android Skill");

        // [2] Iterator Pattern ==> Aggregator
        for (Iterator<String> it = classB.keySet().iterator(); it.hasNext();) {
            String key = it.next();
            System.out.println("이름: " + key + " " + "\tSkill: " + classB.get(key));
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // [3] Smart A반 + Smart B반 통합
        System.out.println("[3] Smart A반 + Smart B반 통합");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        Map<String, String> students = new HashMap<>();
        students.putAll(classA);
        students.putAll(classB);
        for (Map.Entry<String, String> stu : students.entrySet()) {
            System.out.println("이름: " + stu.getKey() + " " + "\tSkill: " + stu.getValue());
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // [4] Android Skill을 가진 학생은 Mobile Class로 이동시킨 후 Smart A+B 반 목록
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        Set<String> skill = Collections.singleton("Android Skill");
        students.values().removeAll(skill);
        System.out.println(students.keySet());
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // [5] Python Skill과 Java Skill을 가진 학생들이 존재하는지 확인
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        Map<String, String> pjs = new HashMap<>(); // Python + Java Skills
        pjs.put("B2", "Python Skill");
        pjs.put("A4", "Java Skill");
        System.out.println(students.entrySet().containsAll(pjs.entrySet())); //AND로 되어있음
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // [6] Smart A반과 Smart B반의 학생이 같은지 확인
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println(classA.keySet().equals(classB.keySet()));
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

    }

}