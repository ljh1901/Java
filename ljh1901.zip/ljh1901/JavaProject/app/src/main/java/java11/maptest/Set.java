package java11.maptest;

//Generics Class 정의
public class Set<T> {

}
