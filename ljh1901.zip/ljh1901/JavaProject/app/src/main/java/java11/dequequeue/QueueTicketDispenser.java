package java11.dequequeue;

// QueueTicketDispenser Class: 번호표를 뽑는다.
public class QueueTicketDispenser {
    // 티켓 번호를 추적
    private static int num = 1;

    // 티켓 번호를 받아오고 레스토랑 큐에 인큐하는 메서드
    public static int takeNum() {
        // offer method를 이용해 현재 티켓 번호를 레스토랑 큐에 인큐(First-in First-out)
        Restaurant.q.offer(num);
        
        // 티켓 번호를 반환하고 다음 고객을 위해 증가
        return num++;
    }
}
