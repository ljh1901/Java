package java11.dequestack;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

public class Book {
    private String title;
    private Deque<Page> pageStack;
    private List<Page> pageList;
    private int currentPageNo;

    //instantiation을 하기 위해 Constructor통해 object 생성
    public Book(String title) {
        this.title = title;
        this.pageStack = new ArrayDeque<>();
        this.pageList = new LinkedList<>();
    }

    
    //title의 getter & setter
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    //원하는 page 출력
    public List<Page> getPageList() {
        return pageList;
    }

    public void setPageList(List<Page> pageList) {
        this.pageList = pageList;
    }

    //page를 추가하는 기능
    public void addPage(Page page) {
        pageList.add(page);
    }

    //next page - page를 하나 추가하기위해pageStack을 이용해 Push method를 사용.
    public void nextPage() {
        pageStack.push(pageList.get(currentPageNo++));
    }

    //page를 하나 삭제하기 위해 pop (method) 사용. Casting을 하기위해 object를 assign - 이전 page 출력 
    public void prevPage() {
        Page page = pageStack.pop();
        currentPageNo = page.getNo();
    }
    
    //page를 출력
    public void view() {
        System.out.println(pageList.get(currentPageNo));
    }


    public void setCurrentPageNo(int currentPageNo) {
        this.currentPageNo = currentPageNo;
    }
   
}
