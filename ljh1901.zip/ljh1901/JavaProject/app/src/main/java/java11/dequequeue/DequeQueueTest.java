package java11.dequequeue;

public class DequeQueueTest {
    public static void main(String[] args) {
        QueueTicketDispenser.takeNum();
        QueueTicketDispenser.takeNum();
        QueueTicketDispenser.takeNum();
        QueueTicketDispenser.takeNum();
        QueueTicketDispenser.takeNum();

        System.out.println("첫번째 손님은 " + Restaurant.firstGuest() + "번 손님입니다..");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        Restaurant.printQueue();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        // 대기행렬에 사람이 있다면 Serving을 해서 Queue의 poll() method 로 대기행렬 삭제
        while (Restaurant.q.size() > 0) {
            Restaurant.serving();
        }

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        System.out.println("Deque는 양방향으로 추가 및 삭제가 가능합니다..");
        QueueTicketDispenser.takeNum();
        QueueTicketDispenser.takeNum();
        QueueTicketDispenser.takeNum();
        Restaurant.printQueue();

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

        //Deque queue의 offer()와 poll() method
        Restaurant.q.offerFirst(100);
        Restaurant.printQueue();

        Restaurant.q.offerLast(200);
        Restaurant.printQueue();

        Restaurant.q.pollFirst();
        Restaurant.printQueue();
        
        Restaurant.q.pollLast();
        Restaurant.printQueue();



    }
}
