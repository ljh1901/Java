package java11.dequestack;

public class Page {
    int no;

    //Constructor 생성 
    String contents;
    public Page(int no, String contents) {
        this.no = no;
        this.contents = contents;
    }

    //Construcotr가 있으니 getter와 setter 설정
    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    // 페이지 출력
    @Override
    public String toString() {
        return no + "페이지===> " + contents;
    }

}
