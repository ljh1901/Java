package java11.settest;

import java.util.HashSet;
import java.util.Set;

// HashsetTest 클래스 정의
public class HashsetTest {
    public static void main(String[] args) {
        // 중복 제거를 위한 HashSet 생성
        Set<Fruit> fruits = new HashSet<>();

        // Obejct 추가
        fruits.add(new Fruit("사과"));
        fruits.add(new Fruit("사과"));

        // 중복 제거 후 size와 내용 출력
        System.out.println(fruits.size());
        System.out.println(fruits);
    }
}
