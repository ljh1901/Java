package java11.treesettest;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetTest {
    public static void main(String[] args) {
        // Set.of: Set Interface의 method (Immutable Set) 형태
        Set<String> sets = Set.of("포도", "수박", "사과", "키위", "망고");

        // HashSet으로 문자열 object 생성
        HashSet<String> hashSet = new HashSet<>(sets);
        System.out.println(hashSet);

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        //Ascending 오름차순 정렬
        TreeSet<String> treeSet = new TreeSet<>(sets);
        System.out.println(treeSet); 
    }
}
